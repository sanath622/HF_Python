from distutils.core import setup
setup(    name         = 'nester',         
          version      = '1.4.0',         
          py_modules   = ['nesterList'],        
          author       = 'Sanath Sastry',        
          author_email = 'sanath622@gmail.com',        
          url          = 'https://www.linkedin.com/in/sanath-sastry-12438a13/',        
          description  = 'A simple printer of nested lists',     
     )
